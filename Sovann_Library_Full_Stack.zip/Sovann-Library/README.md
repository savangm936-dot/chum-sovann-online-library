# បណ្ណាល័យ សុវណ្ណ · SOVANN LIBRARY

## បើកលើម៉ាស៊ីនផ្ទាល់ខ្លួន

ត្រូវការ Node.js 24 និងថតសម្រាប់ទិន្នន័យដែលរក្សាទុកបានជាប់លាប់។ កំណត់ ADMIN_EMAIL និង ADMIN_PASSWORD (យ៉ាងតិច ១២ តួ) ជាអថេរបរិស្ថានសម្ងាត់។ បន្ទាប់មកដំណើរការពាក្យបញ្ជាខាងក្រោម។

    npm run build
    npm start

បើក http://localhost:3000 រួចចូលគណនីម្ចាស់ដែលបានកំណត់នៅ /admin។ សិស្សចុះឈ្មោះលើទំព័រគណនី។ ADMIN_PASSWORD ប្រើសម្រាប់បង្កើតគណនីម្ចាស់ដំបូង។ ពិនិត្យមើល server.mjs សម្រាប់ការកំណត់។

## អ៊ីនធឺណិត

សម្រាប់ការបង្ហោះផ្ទាល់ ដំណើរការ Node ឬ Docker នៅពីក្រោយ HTTPS reverse proxy។ កំណត់ NODE_ENV=production និង PUBLIC_ORIGIN ជាអាសយដ្ឋាន HTTPS ពិត។ ភ្ជាប់ volume នៅ /app/data សម្រាប់ Docker។ ថតនេះមានគណនី ទឹកប្រាក់ សំណើ និងបង្កាន់ដៃ ហើយត្រូវរក្សាទុកជាឯកជន និងបម្រុងទុក។ API Key ទុកក្នុង OPENAI_API_KEY នៅម៉ាស៊ីនមេ។ រូប QR ដើមនៅ public/assets/khqr.png។

The hosted Sites deployment uses its managed login gateway and D1. It grants owner access to the verified account configured in the OWNER_EMAIL secret. Deploy the Worker only behind that gateway. The included Node adapter provides a separate password-based login for independent hosting and strips client identity headers. Docker builds use the included compiled Worker. Build again after changing source.

## ការគ្រប់គ្រង

ទំព័រ /admin អនុញ្ញាតឱ្យកែសៀវភៅ រូបភាព មេរៀន តម្លៃ គណនី និងសិទ្ធិ។ ផលិតផលគំរូដែលត្រូវប្រគល់ជាក់ស្ដែងចាប់ផ្តើមបិទលក់។ បើកលក់ក្រោយពេលម្ចាស់បានកំណត់តម្លៃ និងរៀបចំការប្រគល់។ សៀវភៅនីមួយៗមាន ២ ទំព័រចាប់ផ្តើម។ គម្រោងធម្មតាចាប់ផ្តើមពី ៤ ទំព័រ។ អាចកែខ្លឹមសារ និងតម្លៃ USD/KHR ដាច់ពីគ្នាក្នុង Admin។ សមាជិកភាពប្រចាំខែផុតនៅខែបន្ទាប់តាម UTC។ ការបន្តមុនផុតកំណត់បន្ថែមមួយខែពីថ្ងៃផុតកំណត់។

សូមផ្ទៀងផ្ទាត់គណនីទទួល ចំនួនប្រាក់ រូបិយប័ណ្ណ និងលេខយោងក្នុងប្រវត្តិធនាគារ ABA របស់ម្ចាស់មុនអនុម័ត។ ការអនុម័តនីមួយៗត្រូវការលេខយោងធនាគារដែលមិនធ្លាប់បានអនុម័ត។ Credit រក្សាដាច់គ្នាតាមរូបិយប័ណ្ណ។ ប្រព័ន្ធមិនធ្វើការដកប្រាក់ ឬផ្ទៀងផ្ទាត់ស្វ័យប្រវត្តិតាម PayWay ទេ។

AI text/translation uses chat completions, image generation uses the image API, and voice input/output uses browser speech capabilities with a text fallback. A configured OpenAI account with API billing and appropriate model access is required. Code limits each student to 30 usage units per UTC day (text 1, image 10). A request to the provider consumes units even if the provider fails. Configure provider-side spending controls for your own account.

## Source and verification

- public/ contains UI, artwork, KHQR and dictionary.
- src/worker.js implements the backend. src/seed.json contains initial teaching and catalog material.
- drizzle/ holds the durable schema and transactional ledger rules.
- scripts/build.mjs creates the deployable Worker.
- server.mjs is the independent hosting adapter with SQLite and local login.
- Run python3 tests/test_wallet.py for transaction and concurrency checks.

Run python3 tests/test_http.py in the project root for the end-to-end HTTP test. It creates temporary accounts, checks access before and after a verified top-up, and removes the temporary local database on exit.
