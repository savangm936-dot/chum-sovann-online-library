"""Run with Python 3.11+ against SQLite 3.38+."""
import concurrent.futures
import sqlite3
import tempfile
from pathlib import Path
from threading import Barrier


def connect(path):
    db = sqlite3.connect(path, timeout=10, isolation_level=None)
    db.execute("PRAGMA foreign_keys=ON")
    return db


def denied(fn, message):
    try:
        fn()
    except sqlite3.IntegrityError as exc:
        assert message in str(exc), (message, str(exc))
    else:
        raise AssertionError(f"Expected failure: {message}")


def main():
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "library.db"
        conn = connect(path)
        conn.executescript((Path(__file__).resolve().parents[1]/"drizzle/0000_library.sql").read_text())
        conn.executemany("INSERT INTO users(id,name) VALUES (?,?)", [("s","Student"),("admin","Owner")])
        conn.executemany(
            "INSERT INTO items(id,kind,title,price_usd,price_khr) VALUES (?,?,?,?,?)",
            [(kind,kind,kind,100,4000) for kind in ('book','goods','basic','vip','lifetime')],
        )
        balance = lambda currency: conn.execute(
            "SELECT coalesce(sum(delta),0) FROM ledger WHERE user_id='s' AND currency=?", (currency,)
        ).fetchone()[0]

        def request(ident, amount=100, currency='USD'):
            conn.execute(
                "INSERT INTO topups(id,user_id,currency,amount,reference) VALUES (?,'s',?,?,?)",
                (ident, currency, amount, 'student-receipt')
            )

        def review(ident, bank_ref, status='approved'):
            conn.execute(
                "UPDATE topups SET status=?,reviewed_by='admin',bank_ref=? WHERE id=?",
                (status,bank_ref,ident)
            )

        def buy(ident, kind, currency='USD', amount=100):
            conn.execute(
                "INSERT INTO orders(id,user_id,item_id,currency,amount) VALUES (?,'s',?,?,?)",
                (ident,kind,currency,amount)
            )

        request('one')
        assert balance('USD') == 0
        denied(lambda: buy('empty','goods'), 'insufficient_credit')
        denied(lambda: review('one',''), 'verified_bank_reference_required')
        assert balance('USD') == 0
        review('one','BankABC')
        denied(lambda: review('one','BankABC'), 'already_reviewed')
        request('two')
        denied(lambda: review('two',' bankabc '), 'UNIQUE')
        review('two',None,'rejected')
        assert balance('USD') == 100 and balance('KHR') == 0
        denied(lambda: buy('bad','goods',amount=1), 'item_or_price_changed')
        denied(lambda: buy('wrongcurrency','goods','KHR',4000), 'insufficient_credit')
        denied(lambda: conn.execute("UPDATE ledger SET delta=101"), 'ledger_immutable')

        def race(pair):
            barrier = Barrier(2)
            def run(sql, args):
                db = connect(path)
                try:
                    barrier.wait()
                    db.execute(sql,args)
                    return True
                except sqlite3.IntegrityError:
                    return False
                finally:
                    db.close()
            with concurrent.futures.ThreadPoolExecutor(2) as pool:
                futures = [pool.submit(run,*p) for p in pair]
                return sorted(f.result() for f in futures)

        purchase = "INSERT INTO orders(id,user_id,item_id,currency,amount) VALUES (?,'s','goods','USD',100)"
        assert race([(purchase,('a',)),(purchase,('b',))]) == [False,True]
        assert balance('USD') == 0
        request('three',1000)
        approval = "UPDATE topups SET status='approved',bank_ref='bank002',reviewed_by='admin' WHERE id='three'"
        assert race([(approval,()),(approval,())]) == [False,True]
        assert balance('USD') == 1000

        buy('book1','book')
        denied(lambda: buy('book2','book'), 'already_owned')
        buy('vip1','vip')
        member = lambda: conn.execute("SELECT expires FROM grants WHERE user_id='s' AND item_id='vip'").fetchone()[0]
        first = member()
        buy('vip2','vip')
        assert 28*86400 <= member()-first <= 31*86400
        conn.execute("UPDATE grants SET expires=unixepoch('2040-01-31 23:59:30') WHERE item_id='vip'")
        buy('vip3','vip')
        assert conn.execute("SELECT datetime(?,'unixepoch')",(member(),)).fetchone()[0] == '2040-02-29 23:59:30'
        buy('life1','lifetime')
        denied(lambda: buy('life2','lifetime'), 'already_owned')
        assert conn.execute("SELECT expires FROM grants WHERE item_id='lifetime'").fetchone() == (None,)
        for i in range(4):
            conn.execute("INSERT INTO pages VALUES (?,'book','Page','lesson',1)",(str(i),))
        denied(lambda: conn.execute("INSERT INTO pages VALUES ('5','book','Page','lesson',1)"),'basic_page_limit')
        conn.execute("INSERT INTO pages VALUES ('5','book','Page','lesson',0)")
        denied(lambda: conn.execute("UPDATE pages SET basic=1 WHERE id='5'"),'basic_page_limit')
        denied(lambda: conn.execute("UPDATE items SET kind='vip' WHERE id='book'"),'item_kind_in_use')
        conn.execute("UPDATE users SET disabled=1 WHERE id='s'")
        denied(lambda: buy('disabled','goods'), 'student_unavailable')
        conn.close()
    print("PASS — pending/approval, verified reference reuse, rejection, currency, concurrent approval/spend, price, entitlements, monthly expiry and basic-page limit")


if __name__ == '__main__':
    main()
