import os,tempfile,subprocess,time,secrets, http.client,urllib.parse,json as J
class Resp:
 def __init__(self,r):
  self.status_code=r.status;self.cookie=r.getheader('set-cookie');self.text=r.read().decode()
 def json(self):return J.loads(self.text)
class Session:
 def __init__(self):self.headers={}
 def req(self,method,url,data=None):
  u=urllib.parse.urlsplit(url); c=http.client.HTTPConnection(u.hostname,u.port)
  c.request(method,u.path+('?' +u.query if u.query else ''),data,self.headers);r=Resp(c.getresponse());c.close()
  if r.cookie:self.headers['Cookie']=r.cookie.split(';')[0]
  return r
 def get(self,url):return self.req('GET',url)
 def post(self,url,data=None,json=None,allow_redirects=False):
  self.headers['Content-Type']='application/json' if json else 'application/x-www-form-urlencoded'
  return self.req('POST',url,J.dumps(json) if json else urllib.parse.urlencode(data))
class requests:
 Session=Session
 get=Session().get
 ConnectionError=ConnectionError
origin='http://localhost:3378'
with tempfile.TemporaryDirectory() as d:
 password=secrets.token_urlsafe(18)
 env=dict(os.environ,PORT='3378',PUBLIC_ORIGIN=origin,ADMIN_EMAIL='owner@example.com',ADMIN_PASSWORD=password,DATA_DIR=d)
 proc=subprocess.Popen(['node','server.mjs'],env=env)
 try:
  for i in range(50):
   try:
    if requests.get(origin+'/').status_code==200:break
   except requests.ConnectionError:pass
   time.sleep(.1)
  def login(email,mode):
   s=requests.Session();s.headers.update({'Origin':origin}); r=s.post(origin+'/signin-with-chatgpt',data={'mode':mode,'email':email,'password':password},allow_redirects=False);assert r.status_code==303,(r.status_code,r.text[:120]);return s
  student=login('student@example.com','register');admin=login('owner@example.com','login')
  def get(s,path,status=200):
   r=s.get(origin+path);assert r.status_code==status,(path,r.status_code,r.text[:200]);return r.json()
  def post(s,path,b,status=200):
   r=s.post(origin+path,json=b);assert r.status_code==status,(path,r.status_code,r.text[:200]);return r.json()
  c=get(student,'/api/catalog');assert len(c['pages'])==10 and len(c['items'])>=8
  assert get(student,'/api/me')['user']['usd']==0
  get(student,'/api/admin',403);get(student,'/api/read?id=n5-1',403)
  tid=post(student,'/api/topups',dict(currency='USD',amount=1000,reference='PAID',receipt=''),201)['id']
  assert get(student,'/api/me')['user']['usd']==0
  get(admin,'/api/admin');post(admin,'/api/admin/review',dict(id=tid,decision='approve',bank_ref='confirmed-test',confirmed=True))
  assert get(student,'/api/me')['user']['usd']==1000
  buy=dict(key=secrets.token_hex(16),id='standard',currency='USD',quote=244)
  post(student,'/api/buy',buy,201);post(student,'/api/buy',buy)
  assert get(student,'/api/me')['user']['usd']==756
  get(student,'/api/read?id=n5-1');get(student,'/api/read?id=n3-1',403)
  assert not c['ai'];post(student,'/api/ai',{'prompt':'test','mode':'chat'},503)
  print('PASS HTTP registration, owner-only Admin, protected reading, pending ABA, verified credit, one debit on retry, basic whitelist, AI offline state.')
 finally:proc.terminate();proc.wait()
