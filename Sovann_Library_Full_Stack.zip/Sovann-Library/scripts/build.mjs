import fs from 'node:fs';
import path from 'node:path';
const mime={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json','.webp':'image/webp','.png':'image/png'};
const files={};
function visit(dir){for(const name of fs.readdirSync(dir)){const file=path.join(dir,name);if(fs.statSync(file).isDirectory())visit(file);else files['/'+path.relative('public',file)]=[mime[path.extname(file)]||'application/octet-stream',fs.readFileSync(file).toString('base64')]}}
visit('public');const source=fs.readFileSync('src/worker.js','utf8').replace('// ASSET_BUNDLE',()=> 'const ASSETS='+JSON.stringify(files)+';').replace('// SEED_DATA',()=> 'const SEED='+fs.readFileSync('src/seed.json','utf8')+';');
fs.mkdirSync('dist/server',{recursive:true});fs.writeFileSync('dist/server/index.js',source);
