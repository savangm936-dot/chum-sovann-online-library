CREATE TABLE users (
  id TEXT PRIMARY KEY NOT NULL,
  name TEXT NOT NULL DEFAULT '',
  disabled INTEGER NOT NULL DEFAULT 0 CHECK (disabled IN (0,1))
);
--> statement-breakpoint
CREATE TABLE items (
  id TEXT PRIMARY KEY NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('book','goods','basic','vip','lifetime')),
  title TEXT NOT NULL CHECK (length(trim(title)) > 0),
  image TEXT NOT NULL DEFAULT '',
  price_usd INTEGER NOT NULL DEFAULT 0 CHECK (typeof(price_usd)='integer' AND price_usd BETWEEN 0 AND 1000000000),
  price_khr INTEGER NOT NULL DEFAULT 0 CHECK (typeof(price_khr)='integer' AND price_khr BETWEEN 0 AND 1000000000),
  description TEXT NOT NULL DEFAULT '',
  level TEXT NOT NULL DEFAULT '',
  active INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1))
);
--> statement-breakpoint
CREATE TABLE pages (
  id TEXT PRIMARY KEY NOT NULL,
  book TEXT NOT NULL REFERENCES items(id),
  title TEXT NOT NULL CHECK (length(trim(title)) > 0),
  body TEXT NOT NULL,
  basic INTEGER NOT NULL DEFAULT 0 CHECK (basic IN (0,1))
);
--> statement-breakpoint
CREATE INDEX pages_book ON pages(book);
--> statement-breakpoint
CREATE TABLE topups (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES users(id),
  currency TEXT NOT NULL CHECK (currency IN ('USD','KHR')),
  amount INTEGER NOT NULL CHECK (typeof(amount)='integer' AND amount BETWEEN 1 AND 1000000000),
  reference TEXT,
  receipt TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  bank_ref TEXT,
  reviewed_by TEXT REFERENCES users(id),
  created INTEGER NOT NULL DEFAULT (unixepoch()),
  CHECK (length(trim(coalesce(reference,'')))>0 OR length(coalesce(receipt,''))>0)
);
--> statement-breakpoint
CREATE UNIQUE INDEX topups_bank_reference ON topups(upper(trim(bank_ref))) WHERE status='approved';
--> statement-breakpoint
CREATE INDEX topups_student ON topups(user_id,created DESC);
--> statement-breakpoint
CREATE INDEX topups_queue ON topups(status,created DESC);
--> statement-breakpoint
CREATE TABLE orders (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES users(id),
  item_id TEXT NOT NULL REFERENCES items(id),
  currency TEXT NOT NULL CHECK (currency IN ('USD','KHR')),
  amount INTEGER NOT NULL CHECK (typeof(amount)='integer' AND amount BETWEEN 0 AND 1000000000),
  created INTEGER NOT NULL DEFAULT (unixepoch())
);
--> statement-breakpoint
CREATE INDEX orders_student ON orders(user_id,created DESC);
--> statement-breakpoint
CREATE TABLE grants (
  user_id TEXT NOT NULL REFERENCES users(id),
  item_id TEXT NOT NULL REFERENCES items(id),
  expires INTEGER CHECK (expires IS NULL OR typeof(expires)='integer'),
  active INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1)),
  PRIMARY KEY (user_id,item_id)
);
--> statement-breakpoint
CREATE TABLE ledger (
  user_id TEXT NOT NULL REFERENCES users(id),
  currency TEXT NOT NULL CHECK (currency IN ('USD','KHR')),
  delta INTEGER NOT NULL CHECK (typeof(delta)='integer' AND delta<>0),
  source TEXT PRIMARY KEY NOT NULL,
  created INTEGER NOT NULL DEFAULT (unixepoch())
);
--> statement-breakpoint
CREATE INDEX ledger_balance ON ledger(user_id,currency);
--> statement-breakpoint
CREATE TABLE ai_usage (
  user_id TEXT NOT NULL REFERENCES users(id),
  day TEXT NOT NULL,
  n INTEGER NOT NULL CHECK (typeof(n)='integer' AND n>=0),
  PRIMARY KEY (user_id,day)
);
--> statement-breakpoint
CREATE TRIGGER page_insert_rules BEFORE INSERT ON pages BEGIN
  SELECT CASE WHEN (SELECT kind FROM items WHERE id=NEW.book) IS NOT 'book'
    THEN RAISE(ABORT,'invalid_book') END;
  SELECT CASE WHEN NEW.basic=1 AND (SELECT count(*) FROM pages WHERE basic=1 AND id<>NEW.id)>=4
    THEN RAISE(ABORT,'basic_page_limit') END;
END;
--> statement-breakpoint
CREATE TRIGGER page_update_rules BEFORE UPDATE ON pages BEGIN
  SELECT CASE WHEN (SELECT kind FROM items WHERE id=NEW.book) IS NOT 'book'
    THEN RAISE(ABORT,'invalid_book') END;
  SELECT CASE WHEN NEW.basic=1 AND (SELECT count(*) FROM pages WHERE basic=1 AND id<>OLD.id)>=4
    THEN RAISE(ABORT,'basic_page_limit') END;
END;
--> statement-breakpoint
CREATE TRIGGER preserve_used_kind BEFORE UPDATE OF kind ON items
WHEN NEW.kind<>OLD.kind AND (
  EXISTS (SELECT 1 FROM pages WHERE book=OLD.id)
  OR EXISTS (SELECT 1 FROM grants WHERE item_id=OLD.id)
  OR EXISTS (SELECT 1 FROM orders WHERE item_id=OLD.id)
) BEGIN
  SELECT RAISE(ABORT,'item_kind_in_use');
END;
--> statement-breakpoint
CREATE TRIGGER topup_initial_state BEFORE INSERT ON topups BEGIN
  SELECT CASE WHEN NEW.status<>'pending' OR NEW.reviewed_by IS NOT NULL OR length(trim(coalesce(NEW.bank_ref,'')))>0
    THEN RAISE(ABORT,'pending_required') END;
  SELECT CASE WHEN (SELECT disabled FROM users WHERE id=NEW.user_id) IS NOT 0
    THEN RAISE(ABORT,'student_unavailable') END;
END;
--> statement-breakpoint
CREATE TRIGGER topup_decision BEFORE UPDATE ON topups BEGIN
  SELECT CASE WHEN OLD.status<>'pending' OR NEW.status NOT IN ('approved','rejected')
    THEN RAISE(ABORT,'already_reviewed') END;
  SELECT CASE WHEN NEW.id<>OLD.id OR NEW.user_id<>OLD.user_id OR NEW.currency<>OLD.currency OR NEW.amount<>OLD.amount
    OR NEW.reference IS NOT OLD.reference OR NEW.receipt IS NOT OLD.receipt OR NEW.created<>OLD.created
    THEN RAISE(ABORT,'request_immutable') END;
  SELECT CASE WHEN (SELECT disabled FROM users WHERE id=NEW.reviewed_by) IS NOT 0
    THEN RAISE(ABORT,'reviewer_required') END;
  SELECT CASE WHEN NEW.status='approved' AND length(trim(coalesce(NEW.bank_ref,'')))=0
    THEN RAISE(ABORT,'verified_bank_reference_required') END;
END;
--> statement-breakpoint
CREATE TRIGGER topup_credit AFTER UPDATE OF status ON topups WHEN NEW.status='approved' BEGIN
  INSERT INTO ledger(user_id,currency,delta,source)
  VALUES(NEW.user_id,NEW.currency,NEW.amount,'topup:'||NEW.id);
END;
--> statement-breakpoint
CREATE TRIGGER order_rules BEFORE INSERT ON orders BEGIN
  SELECT CASE WHEN (SELECT disabled FROM users WHERE id=NEW.user_id) IS NOT 0 THEN RAISE(ABORT,'student_unavailable') END;
  SELECT CASE WHEN NOT EXISTS (
    SELECT 1 FROM items WHERE id=NEW.item_id AND active=1
    AND NEW.amount=CASE NEW.currency WHEN 'USD' THEN price_usd WHEN 'KHR' THEN price_khr END
  ) THEN RAISE(ABORT,'item_or_price_changed') END;
  SELECT CASE WHEN EXISTS (
    SELECT 1 FROM grants JOIN items ON items.id=grants.item_id
    WHERE user_id=NEW.user_id AND item_id=NEW.item_id AND grants.active=1
      AND (expires IS NULL OR expires>unixepoch()) AND kind IN ('book','lifetime')
  ) THEN RAISE(ABORT,'already_owned') END;
  SELECT CASE WHEN NEW.amount>(
    SELECT coalesce(sum(delta),0) FROM ledger WHERE user_id=NEW.user_id AND currency=NEW.currency
  ) THEN RAISE(ABORT,'insufficient_credit') END;
END;
--> statement-breakpoint
CREATE TRIGGER order_fulfill AFTER INSERT ON orders BEGIN
  INSERT INTO ledger(user_id,currency,delta,source)
  SELECT NEW.user_id,NEW.currency,-NEW.amount,'order:'||NEW.id WHERE NEW.amount>0;

  -- For a renewal start from the existing expiry. Clamp the day to the final
  -- day of the next calendar month (for example January 31 -> February 28).
  INSERT INTO grants(user_id,item_id,expires,active)
  SELECT NEW.user_id,NEW.item_id,
    CASE WHEN kind IN ('basic','vip') THEN unixepoch(
      datetime(base,'unixepoch','start of month','+1 month'),
      '+'||(min(CAST(strftime('%d',base,'unixepoch') AS INTEGER),
               CAST(strftime('%d',base,'unixepoch','start of month','+2 months','-1 day') AS INTEGER))-1)||' days',
      '+'||(base%86400)||' seconds'
    ) END,1
  FROM (
    SELECT items.kind,
      max(unixepoch(),coalesce(CASE WHEN g.active=1 THEN g.expires END,0)) AS base
    FROM items LEFT JOIN grants g ON g.item_id=items.id AND g.user_id=NEW.user_id
    WHERE items.id=NEW.item_id AND items.kind IN ('book','basic','vip','lifetime')
  ) WHERE true
  ON CONFLICT(user_id,item_id) DO UPDATE SET expires=excluded.expires,active=1;
END;
--> statement-breakpoint
CREATE TRIGGER orders_no_update BEFORE UPDATE ON orders BEGIN SELECT RAISE(ABORT,'order_immutable'); END;
--> statement-breakpoint
CREATE TRIGGER orders_no_delete BEFORE DELETE ON orders BEGIN SELECT RAISE(ABORT,'order_immutable'); END;
--> statement-breakpoint
CREATE TRIGGER ledger_no_update BEFORE UPDATE ON ledger BEGIN SELECT RAISE(ABORT,'ledger_immutable'); END;
--> statement-breakpoint
CREATE TRIGGER ledger_no_delete BEFORE DELETE ON ledger BEGIN SELECT RAISE(ABORT,'ledger_immutable'); END;
--> statement-breakpoint
CREATE TRIGGER topup_no_delete BEFORE DELETE ON topups BEGIN SELECT RAISE(ABORT,'request_immutable'); END;
--> statement-breakpoint
CREATE TABLE setup(id INTEGER PRIMARY KEY);
