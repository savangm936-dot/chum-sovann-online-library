import http from 'node:http';
import { randomBytes, randomUUID, scrypt, createHash, createHmac, timingSafeEqual } from 'node:crypto';
import { promisify } from 'node:util';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync, readdirSync, mkdirSync, writeFileSync, chmodSync } from 'node:fs';
import { resolve, join } from 'node:path';
import worker from './dist/server/index.js';

const port = Number(process.env.PORT || 3000);
const production = process.env.NODE_ENV === 'production';
const external = new URL(process.env.PUBLIC_ORIGIN || 'http://localhost:' + port);
if (production && external.protocol !== 'https:') throw Error('Set PUBLIC_ORIGIN to the external HTTPS origin.');
if (external.pathname !== '/' || external.search || external.hash || external.username || external.password) throw Error('PUBLIC_ORIGIN must be an origin.');
const origin = external.origin;
const secure = external.protocol === 'https:';
const adminEmail = (process.env.ADMIN_EMAIL || '').trim().toLowerCase();
const strong = s => typeof s === 'string' && s.length >= 12 && Buffer.byteLength(s) <= 256;
const validEmail = s => typeof s === 'string' && s.length <= 254 && /^[a-z0-9._+-]+@[a-z0-9.-]+\.[a-z]{2,}$/i.test(s);
if (!validEmail(adminEmail) || !strong(process.env.ADMIN_PASSWORD)) throw Error('Set ADMIN_EMAIL and a unique ADMIN_PASSWORD (12 or more characters).');

const dir = resolve(process.env.DATA_DIR || 'data');
mkdirSync(dir, { recursive: true, mode: 0o700 });
const dbPath = join(dir, 'sovann.sqlite');
const db = new DatabaseSync(dbPath);
chmodSync(dbPath, 0o600);
db.exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;');
db.exec(`
CREATE TABLE IF NOT EXISTS local_migrations(name TEXT PRIMARY KEY,digest TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS local_accounts(
  id TEXT PRIMARY KEY,email TEXT NOT NULL UNIQUE,password_hash TEXT NOT NULL,owner INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS local_sessions(token_hash TEXT PRIMARY KEY,account_id TEXT REFERENCES local_accounts(id),expires INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS local_sessions_expiry ON local_sessions(expires);`);
const digest = value => createHash('sha256').update(value).digest('hex');
for (const name of readdirSync('drizzle').filter(n => n.endsWith('.sql')).sort()) {
  const sql = readFileSync(join('drizzle', name), 'utf8');
  db.exec('BEGIN IMMEDIATE');
  try {
    const applied = db.prepare('SELECT digest FROM local_migrations WHERE name=?').get(name);
    if (applied && applied.digest !== digest(sql)) throw Error('Previously applied migration changed: ' + name);
    if (!applied) {
      db.exec(sql);
      db.prepare('INSERT INTO local_migrations VALUES (?,?)').run(name, digest(sql));
    }
    db.exec('COMMIT');
  } catch (e) { db.exec('ROLLBACK'); throw e; }
}

const derive = promisify(scrypt);
async function hashPassword(pass) {
  const salt = randomBytes(16);
  const key = await derive(pass, salt, 64, { N: 32768, r: 8, p: 1, maxmem: 64*1024*1024 });
  return salt.toString('hex') + '.' + key.toString('hex');
}
async function verify(pass, encoded) {
  const [salt, expected] = encoded.split('.').map(x=>Buffer.from(x, 'hex'));
  const actual = await derive(pass, salt, expected.length, { N: 32768, r: 8, p: 1, maxmem: 64*1024*1024 });
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}
const knownOwner = db.prepare('SELECT owner FROM local_accounts WHERE email=?').get(adminEmail);
if (knownOwner && knownOwner.owner !== 1) throw Error('Reserved administrator login conflicts with an existing student.');
if (!knownOwner) {
  const ownerHash = await hashPassword(process.env.ADMIN_PASSWORD);
  db.prepare('INSERT INTO local_accounts(id,email,password_hash,owner) VALUES(?,?,?,1)').run(randomUUID(),adminEmail,ownerHash);
}
const dummyHash = await hashPassword(randomBytes(32).toString('hex'));
const keyPath = join(dir,'session.key');
try { writeFileSync(keyPath, randomBytes(32), {flag:'wx',mode:0o600}); }
catch(e) { if (e.code !== 'EEXIST') throw e; }
const secret = readFileSync(keyPath);
if (secret.length !== 32) throw Error('Invalid key in data/session.key');
const sign = nonce => createHmac('sha256',secret).update(nonce).digest('base64url');
const cookieName = secure ? '__Host-sovann_session' : 'sovann_local_session';
function cookie(value, age) {
  return cookieName+'='+value+'; Path=/; HttpOnly; SameSite=Lax; Max-Age='+age+(secure?'; Secure':'');
}
function getSession(cookies = '') {
  const pair = cookies.split(';').map(p=>p.trim()).find(p=>p.startsWith(cookieName+'='));
  if (!pair) return null;
  const raw = pair.slice(cookieName.length+1);
  if (!/^[A-Za-z0-9_-]{43}\.[A-Za-z0-9_-]{43}$/.test(raw)) return null;
  const [nonce, mac] = raw.split('.');
  if (!timingSafeEqual(Buffer.from(mac),Buffer.from(sign(nonce)))) return null;
  const hash = digest(raw);
  const account = db.prepare('SELECT a.id,a.email,a.owner FROM local_sessions s JOIN local_accounts a ON a.id=s.account_id WHERE s.token_hash=? AND s.expires>unixepoch()').get(hash);
  return account ? {...account,hash}:null;
}

class D1Statement {
  constructor(sql, values=[]) {this.sql=sql;this.values=values}
  bind(...args) {return new D1Statement(this.sql,args)}
  first(column) {
    const row=db.prepare(this.sql).get(...this.values);
    if (!row) return null;
    return column===undefined?row:row[column];
  }
  all() {
    const rows=db.prepare(this.sql).all(...this.values);
    return {success:true, results:rows, meta:{changes:0}};
  }
  run() {
    const st=db.prepare(this.sql);
    if (st.columns().length) return this.all();
    const r=st.run(...this.values);
    return {success:true,results:[],meta:{changes:Number(r.changes),last_row_id:Number(r.lastInsertRowid)}};
  }
}
const DB = {
  prepare: sql=>new D1Statement(sql),
  batch(stmts) {
    db.exec('BEGIN IMMEDIATE');
    try {const out=stmts.map(st=>st.run());db.exec('COMMIT');return out;}
    catch (e) {db.exec('ROLLBACK');throw e;}
  }
};
const env={DB,OWNER_EMAIL:adminEmail,OPENAI_API_KEY:process.env.OPENAI_API_KEY||''};
for(const key of ['OPENAI_CHAT_MODEL','OPENAI_IMAGE_MODEL']) if(process.env[key]) env[key]=process.env[key];
const esc = value=>String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function safeReturn(s) {
  if (!s || s.length>1500 || !s.startsWith('/') || /[\\\r\n]/.test(s)) return '/account';
  try {const u=new URL(s, origin);return u.origin===origin&&!['/signin-with-chatgpt','/signout-with-chatgpt'].includes(u.pathname)?u.pathname+u.search+u.hash:'/account';}catch{return '/account'}
}
function authScreen(back, register=false, msg='', logout=false) {
  const title=logout?'ចាកចេញពីគណនី':register?'បង្កើតគណនីសិស្ស':'ចូលគណនី';
  const inp=logout?'':'<label>អ៊ីមែល<input name="email" type="email" autocomplete="username" maxlength="254" required></label><label>ពាក្យសម្ងាត់<input type="password" name="password" autocomplete="'+(register?'new-password':'current-password')+'" minlength="'+(register?'12':'1')+'" maxlength="256" required></label>';
  const alt='/signin-with-chatgpt?mode='+(register?'login':'register')+'&amp;return_to='+encodeURIComponent(back);
  const form='<form method="post"><input type="hidden" name="mode" value="'+(register?'register':'login')+'"><input type="hidden" name="return_to" value="'+esc(back)+'">'+inp+'<button>'+title+'</button></form>';
  const body='<!doctype html><html lang="km"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+title+' · Sovann Library</title><style>body{margin:0;padding:5vh 18px;background:#f2f4ff;color:#202748;font:16px/1.9 system-ui,sans-serif}main{max-width:430px;margin:auto;padding:30px;background:white;border:1px solid #ccd3f4;border-radius:16px}label,input,button{display:block;width:100%;box-sizing:border-box}input,button{font:inherit;padding:9px;border:1px solid #adb8d7;border-radius:8px;margin:4px 0 15px}button{background:#4936ad;color:white;cursor:pointer}a{color:#293db0}p[role]{color:#8a2630}</style><main><a href="/">SOVANN LIBRARY</a><h1>'+title+'</h1>'+(msg?'<p role="alert">'+esc(msg)+'</p>':'')+form+(logout?'':'<a href="'+alt+'">'+(register?'មានគណនីហើយ · ចូលគណនី':'សិស្សថ្មី · បង្កើតគណនី')+'</a>')+'</main></html>';
  return body;
}
const authHeaders={'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'same-origin','Content-Security-Policy':"default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'"};
const limits=new Map();
function take(key,max) {
  const now=Date.now();let bucket=limits.get(key);
  if (!bucket||bucket.until<=now) {bucket={count:0,until:now+10*60*1000};limits.set(key,bucket)}
  return ++bucket.count<=max;
}
setInterval(()=>{for(const [key,v] of limits)if(v.until<=Date.now())limits.delete(key);db.exec('DELETE FROM local_sessions WHERE expires<=unixepoch()')},60000).unref();
async function readBody(req,max) {
  const chunks=[];let size=0;
  for await(const chunk of req){size+=chunk.length;if(size>max)throw Object.assign(Error('Too large'),{status:413});chunks.push(chunk)}
  return Buffer.concat(chunks);
}
const server=http.createServer(async(req,res)=>{
  const send=(status,headers,body='')=>{res.writeHead(status,headers);res.end(body)};
  try {
    if (!req.url.startsWith('/') || /[\\\r\n]/.test(req.url)) return send(400,{},'Invalid path');
    const u=new URL(req.url,origin);
    if(u.origin!==origin)return send(400,{},'Invalid origin');
    const mutating=!['GET','HEAD','OPTIONS'].includes(req.method);
    if(mutating && req.headers.origin!==origin)return send(403,{},'Origin mismatch');
    const auth=['/signin-with-chatgpt','/signout-with-chatgpt'].includes(u.pathname);
    const session=getSession(req.headers.cookie);
    if(auth) {
      const logout=u.pathname==='/signout-with-chatgpt';
      const back=safeReturn(u.searchParams.get('return_to'));
      if(req.method==='GET')return send(200,authHeaders,authScreen(back,u.searchParams.get('mode')==='register','',logout));
      if(req.method!=='POST')return send(405,{'Allow':'GET, POST'});
      if(!(req.headers['content-type']||'').startsWith('application/x-www-form-urlencoded'))return send(415,{});
      const form=new URLSearchParams((await readBody(req,6000)).toString());
      const returnTo=safeReturn(form.get('return_to'));
      if(logout) {
        if(session)db.prepare('DELETE FROM local_sessions WHERE token_hash=?').run(session.hash);
        return send(303,{'Location':returnTo,'Set-Cookie':cookie('',0),'Cache-Control':'no-store'});
      }
      const email=(form.get('email')||'').trim().toLowerCase(), pass=form.get('password')||'';
      const register=form.get('mode')==='register';
      const fail=(message,status=400)=>send(status,authHeaders,authScreen(returnTo,register,message));
      if(!take('ip:'+req.socket.remoteAddress,60)||!take('email:'+digest(email),18))return fail('សូមរង់ចាំ ១០ នាទី រួចព្យាយាមម្ដងទៀត។',429);
      if(!validEmail(email)||Buffer.byteLength(pass)>256||!pass)return fail('សូមបំពេញអ៊ីមែល និងពាក្យសម្ងាត់។');
      let account=db.prepare('SELECT * FROM local_accounts WHERE email=?').get(email);
      if(register) {
        if(!strong(pass))return fail('សូមប្រើពាក្យសម្ងាត់យ៉ាងតិច ១២ តួ។');
        if(email===adminEmail||account)return fail('អ៊ីមែលនេះមិនអាចប្រើសម្រាប់បង្កើតគណនីបានទេ។');
        const hash=await hashPassword(pass);const id=randomUUID();
        const result=db.prepare('INSERT OR IGNORE INTO local_accounts(id,email,password_hash) VALUES(?,?,?)').run(id,email,hash);
        if(!result.changes)return fail('អ៊ីមែលនេះមិនអាចប្រើសម្រាប់បង្កើតគណនីបានទេ។');
        account={id};
      } else {
        const ok=await verify(pass,account?.password_hash||dummyHash);
        if(!account||!ok)return fail('អ៊ីមែល ឬពាក្យសម្ងាត់មិនត្រឹមត្រូវ។',401);
      }
      const nonce=randomBytes(32).toString('base64url'),token=nonce+'.'+sign(nonce);
      if(session) db.prepare('DELETE FROM local_sessions WHERE token_hash=?').run(session.hash);
      db.prepare('INSERT INTO local_sessions VALUES(?,?,unixepoch()+604800)').run(digest(token),account.id);
      return send(303,{'Location':returnTo,'Set-Cookie':cookie(token,604800),'Cache-Control':'no-store'});
    }
    const headers=new Headers();
    for(const key of ['content-type','accept','origin','accept-language','if-none-match'])if(typeof req.headers[key]==='string')headers.set(key,req.headers[key]);
    if(session) {
      headers.set('oai-authenticated-user-id',session.id);
      headers.set('oai-authenticated-user-email',session.email);
    }
    const body=mutating?await readBody(req,6*1024*1024):undefined;
    const response=await worker.fetch(new Request(u,{method:req.method,headers,body}),env,{waitUntil(p){p.catch(()=>{})}});
    send(response.status,Object.fromEntries(response.headers),req.method==='HEAD'?'':Buffer.from(await response.arrayBuffer()));
  } catch(e) {if(!res.headersSent)send(e.status||500,{'Cache-Control':'no-store'},e.status===413?'Request too large':'Request failed');else res.destroy()}
});
server.requestTimeout=30000;
server.listen(port,'0.0.0.0',()=>console.log('Sovann Library listening at '+origin));
