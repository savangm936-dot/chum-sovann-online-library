const app = document.querySelector('#app')
const node = (tag, value, cls) => {
  const el = document.createElement(tag)
  if (value !== undefined) el.textContent = String(value)
  if (cls) el.className = cls
  return el
}
const style = node('style')
style.textContent = `
.owner-panel{max-width:1100px;margin:auto;padding:20px;color:#182d53}
.owner-panel h1,.owner-panel h2,.owner-panel h3{line-height:1.65;margin:0 0 12px}
.owner-panel .adm-nav,.owner-panel .adm-actions{display:flex;flex-wrap:wrap;gap:8px;margin:14px 0}
.owner-panel button,.owner-panel .adm-link{font:inherit;border:1px solid #aebbd6;border-radius:8px;background:#fff;color:#233b70;padding:8px 14px;cursor:pointer}
.owner-panel button:disabled{opacity:.55;cursor:wait}
.owner-panel .active,.owner-panel button[type=submit]{background:#4939a2;color:white;border-color:#4939a2}
.owner-panel .adm-card{border:1px solid #d5def1;border-radius:12px;background:white;padding:18px;margin:12px 0}
.owner-panel label{display:block;margin:12px 0;color:#263c62}
.owner-panel input:not([type=checkbox]),.owner-panel select,.owner-panel textarea{box-sizing:border-box;display:block;width:min(100%,620px);font:inherit;color:#162b51;border:1px solid #b4c1da;background:white;padding:8px;border-radius:7px}
.owner-panel .adm-check input{margin-inline-end:9px}
.owner-panel summary{cursor:pointer;font-weight:bold;padding:5px 0}
.owner-panel p{margin:8px 0}.owner-panel .adm-alert{color:#923322}
.owner-panel .adm-note{color:#4a5d79}.owner-panel .adm-img{display:block;max-width:150px;max-height:145px;object-fit:contain}
.owner-panel .adm-card details+details{border-top:1px solid #e0e5ef}
@media(max-width:700px){.owner-panel{padding:10px}.owner-panel .adm-card{padding:13px}.owner-panel .adm-nav button{flex:1 0 auto}}
`
document.head.append(style)
const shell = node('div', undefined, 'owner-panel')
app.replaceChildren(shell)
let tab = 'review'
let data
const kinds = { book:'សៀវភៅ', goods:'ទំនិញ', basic:'ធម្មតា · ១ ខែ', vip:'VIP · ១ ខែ', lifetime:'VIP មួយជីវិត' }
const statuses = {pending:'រង់ចាំផ្ទៀងផ្ទាត់',approved:'អនុម័តរួច',rejected:'បានបដិសេធ'}
const tabs = {review:'សំណើដាក់ប្រាក់',items:'សៀវភៅ និងទំនិញ',pages:'ទំព័រមេរៀន',users:'គណនីសិស្ស',access:'សិទ្ធិអាន',orders:'ការទិញ'}
const note = (parent, txt, alert=false) => {
  const p=node('p',txt,alert?'adm-alert':'adm-note');p.setAttribute('role',alert?'alert':'status');parent.append(p);return p
}
function link(parent,label,href) {
  const a=node('a',label,'adm-link');a.href=href;parent.append(a);return a
}
function button(parent, label, fn, cls) {
  const b=node('button',label,cls);b.type='button';b.onclick=fn;parent.append(b);return b
}
function field(parent, label, value='', type='text', required=false) {
  const l=node('label',label),e=node(type==='textarea'?'textarea':'input')
  if(type!=='textarea')e.type=type;else e.rows=5
  e.required=required;e.value=value??'';l.append(e);parent.append(l);return e
}
function check(parent,label,yes=false) {
  const l=node('label',undefined,'adm-check'),e=node('input');e.type='checkbox';e.checked=!!yes;l.append(e,document.createTextNode(label));parent.append(l);return e
}
function select(parent,label,options,value) {
  const l=node('label',label),s=node('select')
  for(const [k,v] of options){const o=node('option',v);o.value=k;s.append(o)}
  if(value!=null)s.value=value;s.required=true;l.append(s);parent.append(l);return s
}
function card(parent, title) {
  const d=node('section',undefined,'adm-card');if(title)d.append(node('h3',title));parent.append(d);return d
}
function details(parent,title,build) {
  const d=node('details');d.append(node('summary',title));let built=false
  d.ontoggle=()=>{if(d.open&&!built){built=true;build(d)}};parent.append(d);return d
}
function form(parent,endpoint,label,body) {
  const f=node('form'),b=node('button',label);b.type='submit';const msg=node('p',undefined,'adm-alert');msg.setAttribute('role','alert')
  parent.append(f);const submit=()=>{f.append(b,msg)}
  f.onsubmit=async e=>{
    e.preventDefault();if(b.disabled)return;b.disabled=true;msg.textContent=''
    try{const payload=await body();const r=await fetch('/api/admin/'+endpoint,{method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',body:JSON.stringify(payload)})
      if(!r.ok){const result=await r.json().catch(()=>({}));throw Error(result.error||'មិនអាចរក្សាទុកបាន ('+r.status+')')}
      await load('បានរក្សាទុកការផ្លាស់ប្ដូរ។')
    }catch(err){msg.textContent=err.message;b.disabled=false}
  }
  return [f,submit]
}
const userLabel = id => data.users.find(u=>u.id===id)?.name || id || '—'
const itemLabel = id => data.items.find(i=>i.id===id)?.title || id || '—'
const money=(n,c)=> c==='USD'?'$'+(Number(n)/100).toFixed(2):Number(n).toLocaleString()+' ៛'
function date(v){if(!v)return '';const d=new Date(typeof v==='number'&&v<100000000000?v*1000:v);return Number.isNaN(+d)?String(v):d.toLocaleString('km-KH')}
function readImage(file){
  if(!file)return Promise.resolve('')
  if(!['image/jpeg','image/png','image/webp'].includes(file.type))throw Error('សូមជ្រើសរូប JPG, PNG ឬ WebP។')
  if(file.size>512*1024)throw Error('សូមបង្រួមរូបឱ្យតូចជាង ៥១២ KB។')
  return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=()=>reject(Error('បើករូបមិនបាន។'));r.readAsDataURL(file)})
}
function items(parent){
  const add=card(parent);details(add,'បន្ថែមសៀវភៅ ទំនិញ ឬគម្រោង',p=>edit(p,{}))
  const list=card(parent);for(const x of data.items)details(list,(kinds[x.kind]||x.kind)+' · '+x.title+(x.active?'':' · បិទលក់'),p=>edit(p,x))
  function edit(p,x){
    const id=x.id||crypto.randomUUID();const [f,finish]=form(p,'item','រក្សាទុក',async()=>({
      id,kind:kind.value,title:title.value.trim(),description:desc.value.trim(),level:level.value.trim(),image:await readImage(upload.files[0])||url.value.trim()||(retain?.checked?x.image:''),
      price_usd:Math.round(Number(usd.value)*100),price_khr:Number(khr.value),active:enabled.checked?1:0
    }))
    const kind=select(f,'ប្រភេទ',Object.entries(kinds),x.kind||'book')
    const title=field(f,'ឈ្មោះ',x.title,'text',true),desc=field(f,'ពិពណ៌នា',x.description,'textarea'),level=field(f,'កម្រិតសៀវភៅ (N5–N1)',x.level)
    const usd=field(f,'តម្លៃជា USD',(Number(x.price_usd||0)/100).toFixed(2),'number',true);usd.min='0';usd.step='.01'
    const khr=field(f,'តម្លៃជា KHR',x.price_khr||0,'number',true);khr.min='0';khr.step='1'
    const url=field(f,'តំណរូបភាព',x.image?.startsWith('data:')?'':x.image),upload=field(f,'ឬ ជ្រើសរូបភាពថ្មី','','file');upload.accept='image/jpeg,image/png,image/webp'
    let retain;if(x.image?.startsWith('data:'))retain=check(f,'រក្សារូបបច្ចុប្បន្ន',true)
    const enabled=check(f,'ដាក់លក់',x.active??true);finish()
  }
}
function pages(parent){
  const books=data.items.filter(i=>i.kind==='book').map(i=>[i.id,i.title])
  if(!books.length)return note(parent,'សូមបង្កើតសៀវភៅមុនបន្ថែមទំព័រ។')
  const add=card(parent);details(add,'បន្ថែមទំព័រមេរៀន',p=>edit(p,{}))
  const list=card(parent);for(const x of data.pages)details(list,itemLabel(x.book)+' · '+x.title,p=>edit(p,x))
  function edit(p,x){const [f,finish]=form(p,'page','រក្សាទុក',()=>{
    if(basic.checked&&data.pages.filter(y=>y.basic&&y.id!==x.id).length>=4)throw Error('គម្រោងធម្មតាអាចកំណត់បានអតិបរមា ៤ ទំព័រ។')
    return {id:x.id||crypto.randomUUID(),book:book.value,title:title.value.trim(),body:body.value,basic:basic.checked?1:0}
  })
  const book=select(f,'សៀវភៅ',books,x.book),title=field(f,'ចំណងជើង',x.title,'text',true),body=field(f,'មាតិកាមេរៀន',x.body,'textarea',true),basic=check(f,'អនុញ្ញាតឱ្យគម្រោងធម្មតាអាន',x.basic);finish()}
}
function users(parent){const list=card(parent);if(!data.users.length)note(list,'មិនទាន់មានសិស្ស។')
  for(const x of data.users)details(list,x.name||x.id,p=>{text(p,x.id);const [f,finish]=form(p,'user','រក្សាទុក',()=>({id:x.id,name:name.value.trim(),disabled:disabled.checked?1:0}))
    const name=field(f,'ឈ្មោះសិស្ស',x.name,'text',true),disabled=check(f,'ផ្អាកគណនីនេះ',x.disabled);finish()})
}
function text(p,s){p.append(node('p',s))}
function access(parent){
  const people=data.users.map(u=>[u.id,u.name||u.id]);const rights=data.items.filter(i=>i.kind!=='goods').map(i=>[i.id,i.title])
  if(!people.length||!rights.length){note(parent,'ត្រូវមានគណនីសិស្ស និងសៀវភៅ ឬគម្រោងសិន។');return}
  const add=card(parent);details(add,'ផ្ដល់សិទ្ធិអាន',p=>edit(p,{}))
  const list=card(parent);for(const g of data.grants)details(list,userLabel(g.user_id)+' · '+itemLabel(g.item_id),p=>edit(p,g))
  function edit(p,g){const [f,finish]=form(p,'access','រក្សាទុកសិទ្ធិ',()=>({user_id:user.value,item_id:item.value,expires:when.value?Math.floor(new Date(when.value).getTime()/1000):null,active:enabled.checked?1:0}))
    const user=select(f,'សិស្ស',people,g.user_id),item=select(f,'សៀវភៅ ឬគម្រោង',rights,g.item_id)
    if(g.user_id){user.disabled=true;item.disabled=true}
    const when=field(f,'ថ្ងៃផុតកំណត់ · ទុកទទេសម្រាប់សិទ្ធិអចិន្ត្រៃយ៍','','datetime-local')
    if(g.expires){const d=new Date(g.expires*1000);when.value=new Date(+d-d.getTimezoneOffset()*60000).toISOString().slice(0,16)}
    const enabled=check(f,'អនុញ្ញាត',g.active??true);finish()}
}
function review(parent){
  const pending=data.topups.filter(t=>t.status==='pending'),processed=data.topups.filter(t=>t.status!=='pending')
  const section=card(parent,'រង់ចាំផ្ទៀងផ្ទាត់ ('+pending.length+')')
  if(!pending.length)note(section,'មិនមានសំណើរង់ចាំ។')
  for(const t of pending)details(section,userLabel(t.user_id)+' · '+money(t.amount,t.currency),p=>{
    text(p,'សិស្ស · '+userLabel(t.user_id));text(p,'ចំនួនប្រាក់ · '+money(t.amount,t.currency));text(p,'លេខយោងសិស្ស · '+(t.reference||'—'));if(t.created_at)text(p,date(t.created_at))
    if(t.has_receipt||t.receipt||t.receipt_key){const a=link(p,'បើកបង្កាន់ដៃ','/api/receipt?id='+encodeURIComponent(t.id));a.target='_blank';a.rel='noopener'}
    const [f,finish]=form(p,'review','អនុម័ត និងបញ្ចូល Credit',()=>({id:t.id,decision:'approve',confirmed:confirm.checked,bank_ref:bank.value.trim()}))
    const bank=field(f,'លេខយោងប្រតិបត្តិការដែលបានផ្ទៀងផ្ទាត់ក្នុង ABA','','text',true)
    const confirm=check(f,'ខ្ញុំបានពិនិត្យឃើញប្រាក់ចូលពិតក្នុងគណនី ABA ហើយបានផ្ទៀងផ្ទាត់ចំនួនប្រាក់ រូបិយប័ណ្ណ និងលេខយោង។');confirm.required=true;finish()
    details(p,'បដិសេធសំណើនេះ',parent=>{const [reject,end]=form(parent,'review','បញ្ជាក់ការបដិសេធ',()=>({id:t.id,decision:'reject',bank_ref:'',confirmed:false}));note(reject,'សិស្សនឹងឃើញស្ថានភាពបដិសេធ។');end()})
  })
  const hist=card(parent,'ប្រវត្តិផ្ទៀងផ្ទាត់');if(!processed.length)note(hist,'មិនទាន់មានប្រវត្តិ។')
  for(const t of processed)text(hist,[userLabel(t.user_id),money(t.amount,t.currency),statuses[t.status]||t.status,t.bank_ref||t.reference].filter(Boolean).join(' · '))
}
function orders(parent){const list=card(parent);if(!data.orders.length)note(list,'មិនទាន់មានការទិញ។')
  for(const o of data.orders){text(list,[userLabel(o.user_id),o.title||itemLabel(o.item_id),money(o.amount,o.currency),date(o.created_at)].filter(Boolean).join(' · '))}}
const renderers={items,pages,users,access,review,orders}
function render(message){shell.replaceChildren();shell.append(node('h1','ផ្ទាំងគ្រប់គ្រងម្ចាស់វេបសាយ'));link(shell,'ទំព័រដើម','/');if(message)note(shell,message)
  const nav=node('div',undefined,'adm-nav');shell.append(nav)
  for(const [id,label] of Object.entries(tabs)){const b=button(nav,label,()=>{tab=id;render()},tab===id?'active':'');b.setAttribute('aria-pressed',String(tab===id))}
  shell.append(node('h2',tabs[tab]));renderers[tab](shell)
}
async function load(message){let r
  try{r=await fetch('/api/admin',{cache:'no-store',credentials:'same-origin'})
    if(r.status===401||r.status===403){shell.replaceChildren();note(shell,r.status===401?'សូមចូលគណនីម្ចាស់វេបសាយ។':'ទំព័រនេះសម្រាប់គណនីម្ចាស់វេបសាយ។');link(shell,'ចូលគណនី','/signin-with-chatgpt?return_to=%2Fadmin').target='_top';link(shell,'ទំព័រដើម','/');return}
    if(!r.ok)throw Error();data=await r.json();render(message)
  }catch{shell.replaceChildren();note(shell,'មិនអាចបើកទិន្នន័យគ្រប់គ្រង។ សូមព្យាយាមម្ដងទៀត។',true);button(shell,'ផ្ទុកឡើងវិញ',()=>load())}
}
note(shell,'កំពុងផ្ទុកទិន្នន័យ…')
load()
