const $=selector=>document.querySelector(selector);
const get=key=>localStorage.getItem('sovann.'+key)||'';
const put=(key,value)=>localStorage.setItem('sovann.'+key,value);
let japanese=get('language')==='ja';
const tr=(km,ja)=>japanese?ja:km;
const sections=[
 ['books','សៀវភៅ N5–N1','日本語の本'],['grammar','វេយ្យាករណ៍','文法'],['talk','ការសន្ទនា','会話'],['kanji','កានជី','漢字'],['dict','វចនានុក្រម','辞書'],['quiz','លំហាត់ JLPT','JLPT 練習'],['group','ក្រុមសិក្សា','学習グループ'],['video','Video Call','ビデオ通話'],['chat','Chat','チャット'],['class','ថ្នាក់អនឡាញ','オンライン教室'],['account','គណនីសិស្ស','学習者プロフィール'],['plans','សមាជិកភាព','会員プラン'],['about','អំពីយើង','概要']];
const rules=['N は N です','Vた ＋ ことがある','V辞書形 ＋ ようにしている','N ＋ に伴って','N ＋ に値する'];
const chats=[['お名前は何ですか。','តើអ្នកឈ្មោះអ្វី?','ラニーです。','ខ្ញុំឈ្មោះរ៉ានី។'],['日本へ行ったことがありますか。','តើអ្នកធ្លាប់ទៅជប៉ុនទេ?','はい、一度あります。','បាទ ធ្លាប់ទៅម្តង។'],['どのように漢字を覚えていますか。','តើអ្នកចងចាំកានជីដោយរបៀបណា?','毎日書くようにしています。','ខ្ញុំព្យាយាមសរសេររាល់ថ្ងៃ។']];
const kanji=[['日','ひ・ニチ','ថ្ងៃ / ព្រះអាទិត្យ','日曜日 · にちようび'],['月','つき・ゲツ','ខែ / ព្រះចន្ទ','月曜日 · げつようび'],['山','やま・サン','ភ្នំ','富士山 · ふじさん'],['人','ひと・ジン','មនុស្ស','日本人 · にほんじん'],['水','みず・スイ','ទឹក','水曜日 · すいようび']];
const questions=[['N5','私は学生（　）。',['です','から','まで','で'],0],['N4','京都へ行った（　）があります。',['もの','こと','ところ','はず'],1],['N3','健康のため、毎日歩く（　）しています。',['までに','ためで','ように','だけの'],2],['N2','人口の増加（　）、住宅が不足してきた。',['に限り','に反して','に比べ','に伴って'],3],['N1','その研究成果は注目（　）。',['に値する','を余儀なくする','を禁じ得ない','の至りだ'],0]];
const panel=document.createElement('section');panel.id='tool';panel.className='panel';$('#lesson').after(panel);
const quick=document.createElement('section');quick.className='panel quick';$('#books').after(quick);
const controls=document.createElement('div');controls.className='tools';$('header span').replaceWith(controls);
function links(){return sections.map(([id,k,j])=>'<a href="#'+id+'">'+tr(k,j)+'</a>').join('')}
function layout(){
 document.documentElement.lang=japanese?'ja':'km';
 $('nav').innerHTML='<h2>'+tr('មាតិកា','メニュー')+'</h2>'+links();
 quick.innerHTML=links();
 const shortcuts=$('#heroLinks');shortcuts.replaceChildren();for(const [id,label] of [['account',tr('ចូលរៀនដោយប្រើឈ្មោះ','学習プロフィール')],['class',tr('ថ្នាក់អនឡាញ','オンライン授業')]]){const a=document.createElement('a');a.href='#'+id;a.textContent=label;shortcuts.append(a)}
 controls.innerHTML='<button id="lang">'+tr('日本語','ភាសាខ្មែរ')+'</button><button id="theme" aria-label="'+tr('ពន្លឺ ឬងងឹត','テーマ切替')+'">☀ / ☾</button>';
 $('#lang').onclick=()=>{japanese=!japanese;put('language',japanese?'ja':'km');layout();route(false)};
 $('#theme').onclick=()=>put('theme',document.body.classList.toggle('dark')?'dark':'light');
 document.body.classList.toggle('dark',get('theme')==='dark');
 $('#books h2').textContent=tr('សៀវភៅភាសាជប៉ុន N5–N1','日本語の本 N5–N1');$('#books p').textContent=tr('ចុចលើក្របសៀវភៅដើម្បីអានមេរៀន។','表紙を選んでレッスンを読みましょう。');
 $('.hero p').textContent=tr('រៀនភាសាជប៉ុនជាភាសាខ្មែរ','クメール語で学ぶ日本語');
 $('#plans').innerHTML='<h2>'+tr('គម្រោងសមាជិកភាព','会員プラン')+'</h2><p>'+tr('ជ្រើសគម្រោងសម្រាប់មើលតម្លៃ','料金プランを選択')+'</p>'+[['ប្រចាំខែ','月額','2.44'],['ប្រចាំឆ្នាំ','年額','20.59'],['Premium / ខែ','プレミアム月額','20.64'],['ពេញមួយជីវិត','買い切り','34.59']].map(([k,j,p],i)=>'<label><input type="radio" name="plan" value="'+i+'" '+(Number(get('plan'))===i?'checked':'')+'> '+tr(k,j)+' <b class="price">$'+p+'</b></label>').join('');
 $('#plans').onchange=e=>put('plan',e.target.value);
 $('aside article:last-child').innerHTML='<h2>'+tr('ការទូទាត់តាម ABA','ABA 決済')+'</h2><p>'+tr('រង់ចាំភ្ជាប់គណនីហាង ABA មុនបើកទូទាត់ និងផ្ញើបង្កាន់ដៃ។','加盟店設定後に決済・領収書送信を開始します。')+'</p>';
 const payment=$('aside article:last-child');
 payment.insertAdjacentHTML('beforeend','<label>'+tr('មើលរូបបង្កាន់ដៃលើឧបករណ៍នេះ','端末内で領収書をプレビュー')+'<input id="slip" type="file" accept="image/*"></label><img id="previewSlip" hidden alt="ABA" style="width:100%;height:auto">');
 $('#slip').onchange=e=>{const img=$('#previewSlip');if(img.src)URL.revokeObjectURL(img.src);const file=e.target.files[0];img.hidden=!file;if(file)img.src=URL.createObjectURL(file)};

}
let timer,dictPromise;
async function dictionary(){
 panel.insertAdjacentHTML('beforeend','<label>'+tr('ស្វែងរកពាក្យជប៉ុន ឬខ្មែរ','日本語・クメール語で検索')+' <input type="search" id="query"></label><div id="results"></div><button id="more"></button>');
 const input=$('#query'),results=$('#results'),more=$('#more');
 try{dictPromise??=fetch('words.json').then(r=>{if(!r.ok)throw Error();return r.json()});const words=await dictPromise;let limit=20;
 function filter(){const q=input.value.normalize().trim().toLowerCase();const rows=words.filter(row=>row.some(x=>x.normalize().toLowerCase().includes(q)));results.replaceChildren();for(const [word,kata,meaning,type] of rows.slice(0,limit)){const line=document.createElement('div');line.className='line';line.textContent=word+' · '+kata+' — '+meaning+' · '+type;results.append(line)}if(!rows.length)results.textContent=tr('រកមិនឃើញពាក្យនេះទេ។','該当なし');more.hidden=rows.length<=limit;more.textContent=tr('មើលបន្ថែម','もっと見る')}
 input.oninput=()=>{limit=20;filter()};more.onclick=()=>{limit+=20;filter()};filter()
 }catch{dictPromise=null;results.textContent=tr('សូមបើកវចនានុក្រមម្ដងទៀត។','辞書を開き直してください。')}
}
function quiz(){
 let index=0,score=0;
 function next(){clearInterval(timer);if(index===questions.length){panel.innerHTML='<h2>'+tr('ពិន្ទុ','成績')+' '+score+' / '+questions.length+'</h2><button id="again">'+tr('ហាត់ម្ដងទៀត','再挑戦')+'</button>';$('#again').onclick=quiz;return}
 const [level,q,choices,correct]=questions[index];let remaining=30;
 panel.innerHTML='<h2>JLPT · '+level+'</h2><p>'+q+'</p><div class="tools" id="choices"></div><p id="feedback" role="status"></p><button hidden id="next">'+tr('បន្ត','次へ')+'</button>';
 const feedback=$('#feedback');function finish(answer){clearInterval(timer);for(const b of $('#choices').children)b.disabled=true;if(answer===correct)score++;feedback.textContent=(answer===correct?'✓ ':'✗ ')+tr('ចម្លើយត្រឹមត្រូវ','正解')+' · '+choices[correct];$('#next').hidden=false}
 choices.forEach((choice,i)=>{const b=document.createElement('button');b.textContent=choice;b.onclick=()=>finish(i);$('#choices').append(b)});feedback.textContent='30 s';timer=setInterval(()=>{feedback.textContent=--remaining+' s';if(!remaining)finish(-1)},1000);$('#next').onclick=()=>{index++;next()}}
 next()
}
function room(){
 panel.insertAdjacentHTML('beforeend','<p>'+tr('គ្រូបង្កើតតំណបន្ទប់ ហើយផ្ញើឱ្យសិស្ស។ គ្រូចូលគណនី Jitsi ដើម្បីបើកបន្ទប់។ ប្រើ Chat ក្នុងបន្ទប់សម្រាប់សរសេរសារ។','講師がリンクを作成して共有し、Jitsi にログインして開始します。チャットは会議室内で使えます。')+'</p><button id="create">'+tr('បង្កើតតំណបន្ទប់','招待リンクを作成')+'</button><div id="invite"></div>');
 function display(){const code=sessionStorage.getItem('classroom');if(!code||!/^Sovann-[a-f0-9-]+$/.test(code))return;const url='https://meet.jit.si/'+code;$('#invite').innerHTML='<p><a target="_blank" rel="noopener noreferrer" href="'+url+'">'+tr('ចូលបន្ទប់ Jitsi','会議室に入る')+'</a></p><label>'+tr('តំណសម្រាប់ផ្ញើឱ្យសិស្ស','招待リンク')+'<input readonly id="roomCode"></label>';$('#roomCode').value=url;$('#roomCode').onclick=e=>e.target.select()}
 $('#create').onclick=()=>{sessionStorage.setItem('classroom','Sovann-'+crypto.randomUUID());display()};display()
}
function route(scroll=true){
 clearInterval(timer);const id=location.hash.slice(1);panel.replaceChildren();const item=sections.find(s=>s[0]===id);if(!item||id==='books'||id==='plans')return;
 panel.innerHTML='<h2>'+tr(item[1],item[2])+'</h2>';const add=html=>panel.insertAdjacentHTML('beforeend',html);
 if(id==='grammar')lessons.forEach((l,i)=>add('<details><summary>N'+(5-i)+' · '+rules[i]+'</summary><p>'+l[4]+'</p><p>'+l[5]+'</p></details>'));
 if(id==='talk')chats.forEach(([q,k,a,b])=>add('<div class="line"><strong>'+q+'</strong><p>'+k+'</p><details><summary>'+tr('បង្ហាញចម្លើយ','応答を見る')+'</summary>'+a+'<br>'+b+'</details></div>'));
 if(id==='kanji')kanji.forEach(([k,r,m,w])=>add('<details><summary><b>'+k+'</b> · '+m+'</summary>'+r+'<br>'+w+'</details>'));
 if(id==='dict')dictionary();if(id==='quiz'){button(panel,tr('វេយ្យាករណ៍ N5–N1','文法問題'),quiz);button(panel,tr('ពាក្យសព្ទ · ៥ សំណួរ','語彙問題 · 5問'),()=>{panel.replaceChildren();wordQuiz()})}
 if(id==='class')add('<p>'+tr('ចន្ទ ដល់ សុក្រ','月曜日〜金曜日')+' · 8:30–9:30</p>');
 if(['group','class','chat','video'].includes(id))room();
 if(id==='account'){add('<form><label>'+tr('ឈ្មោះសិស្សលើឧបករណ៍នេះ','この端末で使う学習者名')+' <input required maxlength="64" id="name"></label><button>'+tr('រក្សាទុកឈ្មោះ','名前を保存')+'</button></form><p role="status" id="saved"></p><p>'+tr('ការចូលគណនីតាម Google និង Apple រង់ចាំភ្ជាប់។','Google・Apple ログインは設定待ちです。')+'</p>');$('#name').value=get('name');panel.querySelector('form').onsubmit=e=>{e.preventDefault();put('name',$('#name').value.trim());$('#saved').textContent=tr('បានរក្សាទុក','保存しました')}}
 if(id==='about')add('<p>Sovann Library · Japanese Learning Center</p><p>'+tr('បណ្ណាល័យរៀនភាសាជប៉ុនជាភាសាខ្មែរ របស់ ជុំ សុវណ្ណ។','チュム・ソヴァンのクメール語で学ぶ日本語図書館。')+'</p>');
 if(scroll)panel.scrollIntoView({block:'start'})
}
const textLine=(where,txt)=>{const p=document.createElement('p');p.textContent=txt;where.append(p);return p};
const button=(parent,label,fn)=>{const b=document.createElement('button');b.type='button';b.textContent=label;b.onclick=fn;parent.append(b);return b};
let wordsPromise;
function words(){return wordsPromise??=fetch('words.json').then(r=>{if(!r.ok)throw Error();return r.json()}).catch(e=>{wordsPromise=null;throw e})}
async function wordQuiz(){
 const box=document.createElement('div');panel.append(box);
 try{const all=await words();if(!box.isConnected)return;
 const mix=a=>{for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a};
 const pool=mix([...new Map(all.map(row=>[row[2],row])).values()]);let index=0,score=0;
 function ask(){box.replaceChildren();if(index===5){textLine(box,tr('ពិន្ទុសរុប ','得点 ')+score+'/5');button(box,tr('សាកម្ដងទៀត','もう一度'),()=>{panel.replaceChildren();wordQuiz()});return}
 const [word,,answer]=pool[index];textLine(box,(index+1)+'/5 · '+tr('ជ្រើសអត្ថន័យរបស់ ','意味を選んでください ')+word);const timer=textLine(box,'30 s');const controls=document.createElement('div');controls.className='tools';box.append(controls);let left=30,done=false;
 function finish(choice){if(done)return;done=true;clearInterval(timer);controls.querySelectorAll('button').forEach(b=>b.disabled=true);if(choice===answer)score++;textLine(box,(choice===answer?'✓ ':'✗ ')+answer);button(box,tr('បន្ត','次へ'),()=>{index++;ask()})}
 mix([answer,...mix(pool.slice(5)).slice(0,3).map(w=>w[2])]).forEach(choice=>button(controls,choice,()=>finish(choice)));timer=setInterval(()=>{timer.textContent=--left+' s';if(!left)finish(null)},1000)}
 button(box,tr('ចាប់ផ្ដើម · ៥ សំណួរ','開始 · 5問'),ask)
 }catch{textLine(box,tr('សូមបើកលំហាត់ម្តងទៀត។','再度開いてください。'))}
}

layout();route();window.addEventListener('hashchange',()=>route());
