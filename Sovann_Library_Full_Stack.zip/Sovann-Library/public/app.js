'use strict';
const app = document.querySelector('#app');
const route = location.pathname.replace(/\/$/, '') || '/';
const params = new URLSearchParams(location.search);
const titles = {'/':'ទំព័រដើម','/books':'សៀវភៅ N5–N1','/book':'សៀវភៅ','/read':'អានមេរៀន','/dictionary':'វចនានុក្រម','/shop':'ហាងទំនិញ','/cart':'កន្ត្រកទំនិញ','/checkout':'បញ្ជាក់ការទិញ','/wallet':'កាបូបលុយ','/top-up':'ដាក់ប្រាក់','/membership':'សមាជិកភាព','/account':'គណនីសិស្ស','/ai':'ជំនួយការ AI'};
let catalog = {items:[],pages:[],ai:false}, me = {user:null,topups:[],orders:[],grants:[]};
const str = value => String(value ?? '');
const esc = value => str(value).replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const url = (path,id) => path+'?id='+encodeURIComponent(str(id));
const byId = (id) => document.getElementById(id);
const link = (path,label,cls='btn') => '<a class="'+cls+'" href="'+esc(path)+'">'+esc(label)+'</a>';
const head = (title,desc='') => '<div class="section-title"><div><h1>'+esc(title)+'</h1>'+(desc?'<p class="subtitle">'+esc(desc)+'</p>':'')+'</div></div>';
const panel = (html,cls='') => '<section class="panel '+cls+'">'+html+'</section>';
function imageURL(value) {
  const src = str(value);
  if (/^\/(?!\/)/.test(src) || /^https:\/\//i.test(src) || /^data:image\/(png|jpeg|webp);base64,/i.test(src)) return esc(src);
  return '';
}
function money(amount,currency) {
  return currency === 'KHR' ? new Intl.NumberFormat('en-US').format(Number(amount))+' ៛' : '$'+(Number(amount)/100).toFixed(2);
}
const prices = item => ['USD','KHR'].filter(c => item['price_'+c.toLowerCase()] != null && Number(item['price_'+c.toLowerCase()])>0);
const quoted = item => prices(item).map(c => money(item['price_'+c.toLowerCase()],c)).join(' / ');
const findItem = id => catalog.items.find(it=>str(it.id)===str(id));
const books = () => catalog.items.filter(it=>it.kind==='book');
const isPlan = it => ['plan','membership','basic','vip','lifetime'].includes(it.kind);
function note(parent, message, failed=false) {
  parent.textContent = message;
  parent.className = failed ? 'error' : 'notice';
  parent.hidden = false;
}
async function api(path, data) {
  const init = {credentials:'same-origin',headers:{Accept:'application/json'}};
  if (data !== undefined) Object.assign(init, {method:'POST',headers:{...init.headers,'Content-Type':'application/json'},body:JSON.stringify(data)});
  const response=await fetch(path,init);
  let result={};
  try { result=await response.json() } catch { throw Error('មិនអាចអានចម្លើយពីម៉ាស៊ីនមេបាន។ សូមសាកម្តងទៀត។') }
  if(!response.ok) throw Error(result.message || result.error || ('សំណើមិនបានសម្រេច ('+response.status+')'));
  return result;
}
function loginBox() {
  const target='/signin-with-chatgpt?return_to='+encodeURIComponent(location.pathname+location.search);
  return panel('<h2>ចូលគណនីសិស្ស</h2><p>ចូលគណនីរបស់បង ដើម្បីបើកទំព័រនេះ។</p><p class="spacer"><a class="btn" target="_top" href="'+esc(target)+'">ចូលតាម ChatGPT</a></p>');
}
function storageGet(key,fallback){try{return JSON.parse(sessionStorage.getItem(key))??fallback}catch{return fallback}}
function storageSet(key,value){try{sessionStorage.setItem(key,JSON.stringify(value))}catch{}}
const cartKey='sovann.cart.v1';
function getCart(){const cart=storageGet(cartKey,[]);return Array.isArray(cart)?cart.map(str):[]}
function card(it,bookMode=false) {
  const src=imageURL(it.image)||(/^N[1-5]$/.test(it.level)?'/assets/'+it.level.toLowerCase()+'.webp':'');
  const path=url(bookMode?'/book':'/checkout',it.id);
  return '<article class="card">'+(src?'<a class="book-art" href="'+esc(path)+'"><img '+(bookMode?'class="cover" ':'')+'loading="lazy" src="'+src+'" alt="'+esc(it.title)+'"></a>':'')+
    '<h3><a href="'+esc(path)+'">'+esc(it.title)+'</a></h3>'+
    (it.description?'<p>'+esc(it.description)+'</p>':'')+
    (!bookMode&&quoted(it)?'<div class="price">'+esc(quoted(it))+'</div>':'')+
    (bookMode?link(path,'បើកសៀវភៅ','btn alt'): '<div class="actions">'+link(path,'មើលការទិញ','btn alt')+(!isPlan(it)?'<button class="dim" type="button" data-cart-add="'+esc(it.id)+'">ដាក់កន្ត្រក</button>':'')+'</div>')+'</article>';
}
function shelf(list,bookMode=false){return list.length?'<div class="'+(bookMode?'shelf':'grid')+'">'+list.map(it=>card(it,bookMode)).join('')+'</div>':'<p class="notice">មិនទាន់មានធាតុក្នុងបញ្ជីនេះទេ។</p>'}
function home(){
  app.innerHTML='<section class="hero"><div class="hero-copy"><span class="eyebrow">SOVANN LIBRARY</span><h1>បណ្ណាល័យ សុវណ្ណ</h1><p>រៀនភាសាជប៉ុនពី N5 ដល់ N1 ជាភាសាខ្មែរ។</p>'+link('/books','បើកបណ្ណាល័យ')+'</div><img src="/assets/hero.webp" alt="សិស្សរៀនភាសាជប៉ុនក្រោមម្លប់សាគូរ៉ា"></section>'+
    '<div class="section-title"><h2>សៀវភៅភាសាជប៉ុន</h2>'+link('/books','មើលទាំងអស់','')+'</div>'+shelf(books(),true)+
    '<div class="section-title"><h2>រៀន និងអនុវត្ត</h2></div><div class="tiles">'+[
    ['/dictionary','វចនានុក្រម','រកការអាន និងអត្ថន័យខ្មែរ'],['/classroom','ថ្នាក់រៀន','វេយ្យាករណ៍ សន្ទនា និងលំហាត់'],['/ai','ជំនួយការ AI','សួរសំណួរ បកប្រែ និងសន្ទនា']].map(([p,t,d])=>'<a class="tile" href="'+p+'"><b>'+t+'</b><small>'+d+'</small></a>').join('')+'</div>';
}
function bookPage(){
  const it=findItem(params.get('id'));if(!it||it.kind!=='book')return missing();
  const pages=catalog.pages.filter(p=>str(p.book)===str(it.id));
  app.innerHTML=link('/books','សៀវភៅទាំងអស់','breadcrumbs')+head(it.title,it.description)+panel('<h2>មាតិកា</h2>'+(
    pages.length?pages.map((p,i)=>'<div class="entry bar"><strong>'+esc(i+1)+'. '+esc(p.title)+'</strong>'+link(url('/read',p.id),'អានទំព័រ','btn alt')+'</div>').join(''):'<p>កំពុងរង់ចាំការបន្ថែមទំព័រ។</p>'))+
    '<div class="actions">'+link('/membership','មើលសិទ្ធិសមាជិកភាព','btn alt')+(prices(it).length?link(url('/checkout',it.id),'ទិញសៀវភៅ'):'')+'</div>';
}
async function readPage(){
  const id=params.get('id'), p=catalog.pages.find(row=>str(row.id)===id);
  app.innerHTML=(p?link(url('/book',p.book),'ត្រឡប់ទៅមាតិកា','breadcrumbs'):'')+head(p?.title||titles[route]);
  try {
    const data=await api(url('/api/read',id));
    app.insertAdjacentHTML('beforeend',panel('<article class="reading" lang="km">'+esc(data.body)+'</article>','compact'));
    if(p){const siblings=catalog.pages.filter(s=>str(s.book)===str(p.book)),index=siblings.indexOf(p);
      app.insertAdjacentHTML('beforeend','<div class="actions">'+(index>0?link(url('/read',siblings[index-1].id),'ទំព័រមុន','btn alt'):'')+(index+1<siblings.length?link(url('/read',siblings[index+1].id),'ទំព័របន្ទាប់'):'')+'</div>')}
  } catch(e){app.insertAdjacentHTML('beforeend',panel('<h2>សិទ្ធិអាន</h2><p>'+esc(e.message)+'</p><p class="spacer">'+link('/membership','មើលគម្រោងសមាជិកភាព')+'</p>')+(!me.user?loginBox():''))}
}
async function dictionary(){
  app.innerHTML=head(titles[route],'ស្វែងរកតាមហ៊ីរ៉ាហ្គាណា កាតាកាណា កាន់ជី ឬអត្ថន័យខ្មែរ។')+panel('<label class="field">ពាក្យស្វែងរក<input id="query" type="search" placeholder="ឧ. 行きます ឬ ទៅ"></label><p class="muted" id="dictionary-count" aria-live="polite"></p><div id="dictionary-matches"></div><button class="alt" id="dictionary-more" hidden>បង្ហាញបន្ថែម</button>');
  const response=await fetch('/assets/words.json');if(!response.ok)throw Error('មិនអាចបើកវចនានុក្រមបាន។');const words=await response.json();
  let limit=25;
  function display(){const q=byId('query').value.trim().normalize('NFKC').toLowerCase();
    const found=words.filter(row=>row.some(v=>str(v).normalize('NFKC').toLowerCase().includes(q)));
    byId('dictionary-count').textContent=found.length+' ពាក្យ';
    byId('dictionary-matches').innerHTML=found.slice(0,limit).map(([w,k,m,c])=>'<div class="entry"><strong lang="ja">'+esc(w)+'</strong> <small lang="ja">'+esc(k)+'</small><p>'+esc(m)+' · '+esc(c)+'</p></div>').join('');
    byId('dictionary-more').hidden=found.length<=limit;
  }
  byId('query').oninput=()=>{limit=25;display()};byId('dictionary-more').onclick=()=>{limit+=25;display()};display();
}
function shop(){
 const items=catalog.items.filter(it=>!isPlan(it));
 app.innerHTML='<section class="hero small"><div class="hero-copy"><span class="eyebrow">SOVANN SHOP</span><h1>ហាងទំនិញ</h1><p>សៀវភៅ និងទំនិញសម្រាប់ទិញដោយប្រើ Credit។</p></div><img alt="ហាងទំនិញ សុវណ្ណ" src="/assets/shop.webp"></section><div class="bar"><div class="chipset" id="filters"></div>'+link('/cart','កន្ត្រក ('+getCart().length+')','btn alt')+'</div><div id="shop-grid"></div>';
 const categories=['ទាំងអស់',...new Set(items.map(it=>it.kind==='book'?'សៀវភៅ':it.category||'ទំនិញ'))];
 function filter(c){byId('filters').replaceChildren();for(const s of categories){const b=document.createElement('button');b.textContent=s;b.className='alt';b.setAttribute('aria-pressed',s===c);b.onclick=()=>filter(s);byId('filters').append(b)}
 byId('shop-grid').innerHTML=shelf(items.filter(it=>c==='ទាំងអស់'||(it.kind==='book'?'សៀវភៅ':it.category||'ទំនិញ')===c))}
 filter(categories[0]);
}
function cart(){
 const rows=getCart().map(id=>findItem(id)).filter(Boolean);
 app.innerHTML=link('/shop','ត្រឡប់ទៅហាង','breadcrumbs')+head('កន្ត្រកទំនិញ',rows.length?'ជ្រើសទំនិញដែលត្រូវបង់ជាមួយ Credit។':'')+
 (rows.length?rows.map(it=>panel('<div class="bar"><div><h3>'+esc(it.title)+'</h3><p class="price">'+esc(quoted(it))+'</p></div><div class="actions">'+link(url('/checkout',it.id),'បញ្ជាក់ការទិញ')+'<button class="alt" type="button" data-cart-remove="'+esc(it.id)+'">យកចេញ</button></div></div>')).join(''):panel('<p>កន្ត្រកទំនិញនៅទទេ។</p><p class="spacer">'+link('/shop','មើលទំនិញ')+'</p>'));
}
function membership(){
 const list=catalog.items.filter(isPlan);
 app.innerHTML=head(titles[route],'ជ្រើសគម្រោង ដើម្បីមើលតម្លៃ និងបញ្ជាក់ការទិញជាមួយ Credit។')+shelf(list)+panel('<h2>សិទ្ធិអាន</h2><div class="entry"><b>ធម្មតា ១ ខែ</b><p>អានទំព័រដែលម្ចាស់បណ្ណាល័យកំណត់។</p></div><div class="entry"><b>VIP ១ ខែ</b><p>អានគ្រប់មេរៀនរហូតដល់ថ្ងៃផុតកំណត់។</p></div><div class="entry"><b>VIP មួយជីវិត</b><p>អានគ្រប់មេរៀនដោយគ្មានថ្ងៃផុតកំណត់។</p></div>','spacer');
}
function checkout(){
 const it=findItem(params.get('id'));if(!it)return missing();
 app.innerHTML=head(titles[route])+panel('<h2>'+esc(it.title)+'</h2><p>'+esc(it.description)+'</p>');
 if(!me.user){app.insertAdjacentHTML('beforeend',loginBox());return}
 const currencies=prices(it);if(!currencies.length){app.insertAdjacentHTML('beforeend',panel('រង់ចាំម្ចាស់វេបសាយកំណត់តម្លៃ។'));return}
 app.insertAdjacentHTML('beforeend',panel('<form id="purchase" class="form stack"><label>រូបិយប័ណ្ណ<select id="pay-currency">'+currencies.map(c=>'<option>'+c+'</option>').join('')+'</select></label><div class="entry" id="quote"></div><p id="purchase-status" hidden role="status"></p><div class="actions"><button type="submit">បញ្ជាក់ទិញដោយប្រើ Credit</button>'+link('/top-up','ដាក់ប្រាក់','btn alt')+'</div></form>'));
 function quote(){const c=byId('pay-currency').value;byId('quote').textContent='តម្លៃ '+money(it['price_'+c.toLowerCase()],c)+' · សមតុល្យ '+money(me.user[c.toLowerCase()],c)}
 byId('pay-currency').onchange=quote;quote();
 byId('purchase').onsubmit=async e=>{e.preventDefault();const form=e.currentTarget,c=byId('pay-currency').value,keyName='sovann.purchase.'+me.user.id+'.'+it.id+'.'+c;
 const key=storageGet(keyName,null)||crypto.randomUUID();storageSet(keyName,key);const btn=form.querySelector('button');btn.disabled=true;byId('pay-currency').disabled=true;
 try{await api('/api/buy',{id:it.id,currency:c,key,quote:it['price_'+c.toLowerCase()]});storageSet(keyName,null);storageSet(cartKey,getCart().filter(x=>x!==str(it.id)));
 form.innerHTML='<p class="notice good">បានទិញដោយប្រើ Credit រួចរាល់។</p><div class="actions">'+link('/wallet','មើលប្រវត្តិកាបូបលុយ','btn alt')+(it.kind==='book'?link(url('/book',it.id),'បើកសៀវភៅ'):'')+'</div>';
 }catch(err){btn.disabled=false;byId('pay-currency').disabled=false;note(byId('purchase-status'),err.message,true)}};
}
const statusLabel = s => ({pending:'រង់ចាំផ្ទៀងផ្ទាត់',approved:'បានអនុម័ត',rejected:'ត្រូវបានបដិសេធ',completed:'បានសម្រេច',paid:'បានទិញ'})[s]||str(s);
function history(rows,empty,render){return rows?.length?rows.map(r=>'<div class="entry">'+render(r)+'</div>').join(''):'<p class="muted">'+esc(empty)+'</p>'}
function wallet(){
 app.innerHTML=head(titles[route]);
 if(!me.user){app.insertAdjacentHTML('beforeend',loginBox());return}
 app.insertAdjacentHTML('beforeend','<div class="grid">'+['USD','KHR'].map(c=>'<div class="card"><span>Credit ដែលបានអនុម័ត · '+c+'</span><div class="money">'+money(me.user[c.toLowerCase()],c)+'</div></div>').join('')+'</div><div class="bar">'+link('/top-up','ដាក់ប្រាក់ (Top Up)')+'<small>ការដកប្រាក់មិនទាន់បើក។</small></div>'+
 panel('<h2>ប្រវត្តិដាក់ប្រាក់</h2>'+history(me.topups,'មិនទាន់មានសំណើដាក់ប្រាក់។',r=>'<b>'+esc(money(r.amount,r.currency))+'</b> · '+esc(statusLabel(r.status))+(r.reference?'<p>លេខយោង '+esc(r.reference)+'</p>':'')))+
 panel('<h2>ប្រវត្តិទិញ</h2>'+history(me.orders,'មិនទាន់មានការទិញ។',r=>'<b>'+esc(r.title||findItem(r.item_id)?.title||r.item_id||r.id)+'</b> · '+esc(money(r.amount??r.total,r.currency)))));
}
function minorUnits(input,currency){
 const text=input.trim();if(!(/^(?:0|[1-9]\d{0,9})(?:\.\d{1,2})?$/.test(text)))return null;
 const [whole,frac='']=text.split('.');if(currency==='KHR'&&frac)return null;
 const n=currency==='KHR'?Number(whole):Number(whole)*100+Number(frac.padEnd(2,'0'));
 return Number.isSafeInteger(n)&&n>0?n:null;
}
function fileData(file){return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=()=>reject(Error('មិនអាចអានរូបភាពបាន។'));r.readAsDataURL(file)})}
function topup(){
 app.innerHTML=link('/wallet','ត្រឡប់ទៅកាបូបលុយ','breadcrumbs')+head('ដាក់ប្រាក់តាម ABA Bank');
 if(!me.user){app.insertAdjacentHTML('beforeend',loginBox());return}
 app.insertAdjacentHTML('beforeend',panel('<form class="stack form" id="fund"><div class="grid"><label>រូបិយប័ណ្ណ<select id="fund-currency"><option>USD</option><option>KHR</option></select></label><label>ចំនួនប្រាក់<input required id="fund-amount" inputmode="decimal" placeholder="0.00" autocomplete="off"></label></div><div class="paygrid"><div class="stack"><h2>គណនីទទួលប្រាក់</h2><p><strong>SOVANN CHUM</strong></p><p>KHR · 017 441 616<br>USD · 017 441 615</p><p>ស្កេន KHQR ឬផ្ទេរតាមលេខគណនី ABA ក្នុងរូបិយប័ណ្ណដែលបានជ្រើស។</p></div><a href="/assets/khqr.png" target="_blank" rel="noopener"><img class="qr" src="/assets/khqr.png" alt="ABA KHQR ដើមរបស់ SOVANN CHUM"></a></div><label>លេខយោងប្រតិបត្តិការ ABA<input id="fund-ref" maxlength="120" autocomplete="off"></label><label>ឬរូបបង្កាន់ដៃ<input id="fund-file" type="file" accept="image/jpeg,image/png"></label><small>ជ្រើសរូប PNG ឬ JPEG ទំហំមិនលើស ៨៥០ KB។</small><p class="notice">បន្ទាប់ពីផ្ញើ សំណើនឹងរង់ចាំការផ្ទៀងផ្ទាត់ប្រាក់ចូលក្នុង ABA ដោយម្ចាស់វេបសាយ។</p><p id="fund-status" role="status" hidden></p><button type="submit">ផ្ញើសំណើដាក់ប្រាក់</button></form>'));
 byId('fund-currency').onchange=()=>{byId('fund-amount').placeholder=byId('fund-currency').value==='KHR'?'0':'0.00'};
 byId('fund').onsubmit=async e=>{e.preventDefault();const f=e.currentTarget,btn=f.querySelector('button');const c=byId('fund-currency').value,amount=minorUnits(byId('fund-amount').value,c),reference=byId('fund-ref').value.trim(),file=byId('fund-file').files[0];
 btn.disabled=true;
 try{if(!amount)throw Error('សូមបញ្ចូលចំនួនប្រាក់វិជ្ជមានត្រឹមត្រូវតាមរូបិយប័ណ្ណ។');if(!reference&&!file)throw Error('សូមបញ្ចូលលេខយោង ឬភ្ជាប់រូបបង្កាន់ដៃ។');
 if(file&&(!['image/png','image/jpeg'].includes(file.type)||file.size>850000))throw Error('សូមជ្រើសរូប PNG ឬ JPEG ទំហំមិនលើស ៨៥០ KB។');
 const receipt=file?await fileData(file):'';
 await api('/api/topups',{currency:c,amount,reference,receipt});
 f.innerHTML='<h2>រង់ចាំផ្ទៀងផ្ទាត់</h2><p>សំណើដាក់ '+esc(money(amount,c))+' ត្រូវបានទទួល។ ក្រោយ Admin ពិនិត្យប្រាក់ចូលក្នុង ABA និងអនុម័ត Credit នឹងបង្ហាញក្នុងកាបូប។</p>'+link('/wallet','មើលស្ថានភាពសំណើ');
 }catch(err){btn.disabled=false;note(byId('fund-status'),err.message,true)}};
}
function account(){
 app.innerHTML=head(titles[route]);
 if(!me.user){app.insertAdjacentHTML('beforeend',loginBox());return}
 app.insertAdjacentHTML('beforeend',panel('<form id="profile" class="stack form"><label>ឈ្មោះសិស្ស<input id="display-name" maxlength="64" value="'+esc(me.user.name)+'" required></label><button>រក្សាទុកឈ្មោះ</button><p hidden role="status" id="profile-message"></p></form>')+
 panel('<h2>សិទ្ធិអានរបស់ខ្ញុំ</h2>'+history(me.grants,'គណនីនេះមិនទាន់មានសិទ្ធិអានដែលបានផ្ដល់ទេ។',g=>{const d=g.expires?new Date(Number(g.expires)*1000):null;const usable=g.active&&(!d||d.getTime()>Date.now());return '<strong>'+esc(g.title||g.item_id)+'</strong><p>'+esc(usable?'មានសុពលភាព':'ផុតកំណត់ ឬបិទសិទ្ធិ')+(d&&Number.isFinite(d.getTime())?' · '+esc(d.toLocaleDateString('km-KH')):g.active?' · គ្មានថ្ងៃផុតកំណត់':'')+'</p>'}))+
 '<div class="actions">'+(me.user.admin?link('/admin','បើក Admin Panel'):'')+'<a class="btn alt" target="_top" href="/signout-with-chatgpt?return_to=/">ចាកចេញពីគណនី</a></div>');
 byId('profile').onsubmit=async e=>{e.preventDefault();const f=e.currentTarget,btn=f.querySelector('button'),name=byId('display-name').value.trim();if(!name)return;btn.disabled=true;try{await api('/api/profile',{name});note(byId('profile-message'),'បានរក្សាទុកឈ្មោះសិស្ស។')}catch(err){note(byId('profile-message'),err.message,true)}finally{btn.disabled=false}};
}
function assistant(){
 app.innerHTML=head('ជំនួយការ AI','សួរសំណួរ បកប្រែជប៉ុន–ខ្មែរ សន្ទនាដោយសំឡេង និងបង្កើតរូបភាព។');
 if(!catalog.ai){app.insertAdjacentHTML('beforeend',panel('<h2>Sovann AI Assistant</h2><p>សេវា AI មិនទាន់បើក។ ម្ចាស់វេបសាយត្រូវភ្ជាប់សោសេវា AI នៅលើម៉ាស៊ីនមេ។</p><p class="spacer">'+link('/dictionary','ប្រើវចនានុក្រមជប៉ុន–ខ្មែរ','btn alt')+'</p>'));return}
 if(!me.user){app.insertAdjacentHTML('beforeend',loginBox());return}
 app.insertAdjacentHTML('beforeend',panel('<form id="ask-ai" class="stack form"><label>មុខងារ<select id="ai-mode"><option value="chat">សួរសំណួរ</option><option value="translate">បកប្រែជប៉ុន ↔ ខ្មែរ</option><option value="voice">សន្ទនាដោយសំឡេង</option><option value="image">បង្កើតរូបភាព</option></select></label><label>សំណួរ ឬអត្ថបទ<textarea id="prompt" maxlength="3000" required></textarea></label><div id="voice-controls" hidden><label>ភាសាសំឡេង<select id="voice-language"><option value="km-KH">ភាសាខ្មែរ</option><option value="ja-JP">日本語</option></select></label><button class="alt" id="record" type="button">និយាយ</button><p class="muted" id="voice-note">ពិនិត្យអត្ថបទសំឡេង រួចចុចផ្ញើ។</p></div><div class="actions"><button id="ask" type="submit">ផ្ញើទៅ AI</button></div><p id="ai-status" hidden role="status"></p></form><div class="spacer" id="answer"></div>'));
 const SpeechInput=window.SpeechRecognition||window.webkitSpeechRecognition;
 let recognition=null;
 function stopVoice(){if(recognition){try{recognition.stop()}catch{}}window.speechSynthesis?.cancel()}
 byId('ai-mode').onchange=()=>{stopVoice();byId('voice-controls').hidden=byId('ai-mode').value!=='voice';if(!SpeechInput){byId('record').disabled=true;byId('voice-note').textContent='កម្មវិធីរុករកនេះមិនអាចទទួលសំឡេងបាន។ សូមវាយសំណួរ។'}};
 byId('record').onclick=()=>{if(!SpeechInput)return;stopVoice();recognition=new SpeechInput();recognition.lang=byId('voice-language').value;recognition.interimResults=false;
 recognition.onresult=e=>{byId('prompt').value=Array.from(e.results,r=>r[0].transcript).join(' ')};recognition.onend=()=>{byId('record').disabled=false};recognition.onerror=()=>{byId('voice-note').textContent='មិនអាចស្ដាប់បាន។ សូមពិនិត្យមីក្រូហ្វូន ឬវាយសំណួរ។'};
 try{recognition.start();byId('record').disabled=true}catch{byId('voice-note').textContent='សូមពិនិត្យសិទ្ធិមីក្រូហ្វូន។'}};
 addEventListener('pagehide',stopVoice,{once:true});
 const history=[];
 byId('ask-ai').onsubmit=async e=>{e.preventDefault();const mode=byId('ai-mode').value,prompt=byId('prompt').value.trim(),status=byId('ai-status');if(!prompt)return;
 byId('ask').disabled=true;note(status,'កំពុងរង់ចាំចម្លើយពីសេវា AI…');
 try{const context=mode==='voice'?history.slice(-2).map(([q,a])=>'User: '+q+'\nAssistant: '+a).join('\n').slice(-1600):'';
 const dialogue=context ? (context+'\nUser: ').slice(-Math.max(0,3000-prompt.length)) : '';
 const result=await api('/api/ai',{mode:mode==='voice'?'chat':mode,prompt:(dialogue+prompt).slice(-3000)});
 if(mode==='image'){const src=imageURL(result.image);if(!src)throw Error('សេវាមិនបានផ្ដល់រូបភាព។');byId('answer').innerHTML='<img class="preview" src="'+src+'" alt="'+esc(prompt)+'">'}else{if(!result.text)throw Error('សេវាមិនបានផ្ដល់ចម្លើយ។');
 byId('answer').innerHTML='<p class="ai-answer">'+esc(result.text)+'</p>';if(mode==='voice'){history.push([prompt,result.text]);if(window.speechSynthesis){const utter=new SpeechSynthesisUtterance(result.text);utter.lang=byId('voice-language').value;window.speechSynthesis.cancel();window.speechSynthesis.speak(utter)}}}
 status.hidden=true;
 }catch(err){note(status,err.message,true)}finally{byId('ask').disabled=false}};
}
function missing(){app.innerHTML=head('រកមិនឃើញទំព័រ')+link('/','ត្រឡប់ទៅទំព័រដើម')}
document.addEventListener('click',event=>{
 const add=event.target.closest('[data-cart-add]');
 if(add){const id=add.dataset.cartAdd;storageSet(cartKey,[...new Set([...getCart(),id])]);add.textContent='បានដាក់កន្ត្រក';const badge=document.querySelector('a[href="/cart"]');if(badge)badge.textContent='កន្ត្រក ('+getCart().length+')'}
 const remove=event.target.closest('[data-cart-remove]');if(remove){storageSet(cartKey,getCart().filter(id=>id!==remove.dataset.cartRemove));cart()}
});
async function begin(){
 const navigation = {'/book':'/books','/read':'/books','/top-up':'/wallet','/checkout':'/shop','/cart':'/shop'};
 const active=navigation[route]||route;
 document.querySelectorAll('.navigation a').forEach(a=>{if(a.getAttribute('href')===active)a.setAttribute('aria-current','page')});
 const media=matchMedia('(max-width:810px)');const menu=byId('site-menu');menu.open=!media.matches;
 media.addEventListener?.('change',e=>{menu.open=!e.matches});
 document.title=(titles[route]||'បណ្ណាល័យ សុវណ្ណ')+' · SOVANN LIBRARY';
 try{
   [catalog,me]=await Promise.all([api('/api/catalog'),api('/api/me')]);
   if(me.user?.admin)byId('owner-nav').hidden=false;
   const pages={'/':home,'/books':()=>{app.innerHTML=head(titles[route],'ជ្រើសសៀវភៅ ដើម្បីមើលមាតិកា និងបើកអានតាមទំព័រ។')+shelf(books(),true)},'/book':bookPage,'/read':readPage,'/dictionary':dictionary,'/shop':shop,'/cart':cart,'/checkout':checkout,'/wallet':wallet,'/top-up':topup,'/membership':membership,'/account':account,'/ai':assistant};
   await (pages[route]||missing)();
 }catch(err){app.innerHTML=head(titles[route]||'បណ្ណាល័យ សុវណ្ណ')+panel('<p class="error">'+esc(err.message)+'</p><p class="spacer">'+link(location.pathname+location.search,'សាកម្តងទៀត','btn alt')+'</p>')}
}
begin();
